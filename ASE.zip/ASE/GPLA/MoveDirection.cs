﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPLA
{
    /// <summary>
    /// move direction class 
    /// </summary>
    class MoveDirection
    {
        /// <summary>
        /// move default constructor
        /// </summary>
        public MoveDirection()
        {

        }

        /// <summary>
        /// getter and setter
        /// </summary>
        public int x { get; set; }
        public int y { get; set; }
    }
}
